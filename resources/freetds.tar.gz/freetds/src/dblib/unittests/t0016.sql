create table #dblib0016 (f1 int not null, s1 int null, f2 numeric(10,2) null, f3 varchar(255) not null, f4 datetime null, [group] varchar(20)) 
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go

