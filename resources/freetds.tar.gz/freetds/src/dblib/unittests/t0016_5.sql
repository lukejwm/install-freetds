create table #dblib0016 (f0 int not null, f1 varchar(60) not null, f2 varchar(60) not null, f3 varchar(60) not null, f4 varchar(60) not null, f5 varchar(60) not null, f6 varchar(60) not null, f7 varchar(60) not null, f8 varchar(60) not null, f9 varchar(60) not null, f10 varchar(60) not null, f11 varchar(60) not null, f12 varchar(60) not null, f13 varchar(60) not null, f14 varchar(60) not null, f15 varchar(60) not null, f16 varchar(60) not null, f17 varchar(60) not null, f18 varchar(60) not null, f19 varchar(60) not null, f20 varchar(60) not null)
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go
