select 1 select 2
go
