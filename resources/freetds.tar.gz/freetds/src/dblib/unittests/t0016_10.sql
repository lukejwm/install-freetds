set textsize 65536
create table #dblib0016 (id int not null, data image)
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go
